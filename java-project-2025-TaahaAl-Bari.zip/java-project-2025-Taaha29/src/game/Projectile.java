package game;

import city.cs.engine.*;

public class Projectile extends DynamicBody {
    public Projectile(World world, Shape shape) {
        super(world, shape);
        this.setGravityScale(0); // No gravity (straight motion)
    }
}
