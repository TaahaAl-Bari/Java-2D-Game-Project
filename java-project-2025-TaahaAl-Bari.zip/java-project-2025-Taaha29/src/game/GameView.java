package game;

import city.cs.engine.UserView;
import city.cs.engine.*;
import org.jbox2d.common.Vec2;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.GradientPaint;
import java.io.File;
import java.io.IOException;
import javax.swing.*;
import java.awt.*;

public class GameView extends UserView {
    private Game game;
    private Font gameFont;
    private Image heartImage;
    private Image blackHeartImage;
    private Image background;
    private Image coinImage;

    public GameView(GameWorld world, int width, int height, Game game) {
        super(world, width, height);
        this.game = game;
        background = new ImageIcon("data/ninjatemple.png").getImage();

        coinImage = new ImageIcon("data/coin.png").getImage();

        // Load custom font
        try {
            gameFont = Font.createFont(Font.TRUETYPE_FONT, new File("data/LilitaOne-Regular.ttf")).deriveFont(24f);
        } catch (FontFormatException | IOException e) {
            e.printStackTrace();
            gameFont = new Font("Arial", Font.BOLD, 24);
        }

        // Load the heart images
        heartImage = new ImageIcon("data/heart.png").getImage();
        blackHeartImage = new ImageIcon("data/heart_black.png").getImage();

        // Try to load the custom font
        try {
            gameFont = Font.createFont(Font.TRUETYPE_FONT, new File("data/LilitaOne-Regular.ttf")).deriveFont(35f);
        } catch (FontFormatException | IOException e) {
            e.printStackTrace();
            gameFont = new Font("Arial", Font.BOLD, 24);
        }
    }



    @Override
    protected void paintForeground(Graphics2D g) {
        super.paintForeground(g);

        // Set a more subtle background gradient with lower opacity
        GradientPaint gradient = new GradientPaint(0, 0, new Color(255, 255, 255, 90), 0, getHeight(), new Color(255, 255, 255, 0));
        g.setPaint(gradient);
        g.fillRect(0, 0, getWidth(), getHeight());  // Softer gradient from top to bottom

        // Add the health bar text
        String healthText = "Health: ";

        // Check if the player is alive or dead
        boolean isPlayerAlive = game.getPlayer().isAlive();

        // Draw the health text
        g.setFont(gameFont);
        g.setColor(Color.WHITE);
        g.drawString(healthText, 20, 40);  // Position the text in top left corner

        // Resize and position the heart image
        int heartImageX = 132;  // X position of the heart image
        int heartImageY = 10;   // Y position of the heart image
        int heartImageWidth = 45;   // Width of the heart image
        int heartImageHeight = 45;  // Height of the heart image

        if (isPlayerAlive) {
            // Draw the normal heart (alive state)
            g.drawImage(heartImage, heartImageX, heartImageY, heartImageWidth, heartImageHeight, null);
        } else {
            // If the player is dead, modify the size and position of the black heart
            int blackHeartX = 95;  // X position of the black heart image
            int blackHeartY = -13;   // Y position of the black heart image
            int blackHeartWidth = 120;  // Width of the black heart image
            int blackHeartHeight = 90; // Height of the black heart image

            // Draw the black heart (dead state) with a different position and size
            g.drawImage(blackHeartImage, blackHeartX, blackHeartY, blackHeartWidth, blackHeartHeight, null);
        }

        // Add a very subtle glow effect (faint shadow behind the text)
        String text = "Enemies Taken Down " + game.getEnemiesDefeated() + "/" + game.getTotalEnemiesToDefeat();

        // Set the glow effect as a faint shadow
        g.setFont(gameFont);
        g.setColor(new Color(0, 0, 0, 50));  // Soft black shadow with lower opacity for subtle glow
        g.drawString(text, getWidth() - 405, 45);  // Positioning the shadow very close to the text

        // Draw the main text on top (white color)
        g.setColor(Color.WHITE);
        g.drawString(text, getWidth() - 400, 40);  // Position the text properly

        // Display the coin count
        String coinText = "Coins: " + game.getPlayer().getCoinsCollected();

        // Add a subtle glow effect to the coin text
        g.setFont(gameFont);
        g.setColor(new Color(0, 0, 0, 50));  // Soft black shadow
        g.drawString(coinText, getWidth() - 150, 80);  // Adjust position

        g.setColor(Color.WHITE);
        g.drawString(coinText, getWidth() - 145, 75);  // Position the coin text on the screen
    }

    @Override
    protected void paintBackground(Graphics2D g) {
        g.drawImage(background, 0, 0, this);

        try {
            // Load the custom font
            Font lilitaOne = Font.createFont(Font.TRUETYPE_FONT, new File("data/LilitaOne-Regular.ttf")).deriveFont(Font.BOLD, 16);
            g.setFont(lilitaOne);
        } catch (Exception e) {
            System.out.println("Font not found, using default.");
            g.setFont(new Font("Arial", Font.BOLD, 17));
        }

        g.setColor(new Color(255, 255, 255, 180)); // White with slight transparency

        // Draw the controls text at a specific position
        int textX = 105;  // Adjust X position as needed
        int textY = 430;  // Adjust Y position as needed
        g.drawString("CONTROLS", textX, textY);
        g.drawString("Left & Right Key: Move", textX, textY + 25);
        g.drawString("Spacebar: Jump", textX, textY + 50);
        g.drawString("'F' Key: Sword Attack", textX, textY + 75);
        g.drawString("'S' Key: Shuriken Attack", textX, textY + 100);
    }
}
