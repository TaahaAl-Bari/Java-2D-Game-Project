package game;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;

public class Coin extends DynamicBody {
    private static final Shape coinShape = new CircleShape(1f); // Make the coin round with radius of 1
    private static final BodyImage coinImage = new BodyImage("data/coin.png", 3f); // Set the image and size

    private float baseY;  // <-- Store the Y position of Coin

    public Coin(World world) {
        super(world, coinShape);
        addImage(coinImage);

        // Set the coin's gravity scale to zero (prevents it from falling)
        setGravityScale(0);
    }

    @Override
    public void setPosition(Vec2 position) {
        super.setPosition(position);
        baseY = position.y; // store the Y-position as this coin's baseY for bobbing
    }

    // Coin's Behaviour to "bob" up and down
    public void update() {
        float oscillation = (float) Math.sin(System.currentTimeMillis() / 50.0) * 0.02f; // smoother bobbing
        setPosition(new Vec2(getPosition().x, baseY + oscillation));
    }
}
