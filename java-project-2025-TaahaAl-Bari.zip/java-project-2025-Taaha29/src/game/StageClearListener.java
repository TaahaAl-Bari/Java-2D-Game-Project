package game;

import city.cs.engine.CollisionEvent;
import city.cs.engine.CollisionListener;

public class StageClearListener implements CollisionListener {
    private Game game;

    public StageClearListener(Game game) {
        this.game = game;
    }

    @Override
    public void collide(CollisionEvent e) {
        if (e.getOtherBody() instanceof StageClearSign) {
            new StageClearScreen(game);
        }
    }
}
