package game;

import city.cs.engine.Shape;
import city.cs.engine.Walker;
import org.jbox2d.common.Vec2;
import city.cs.engine.World;
import city.cs.engine.*;
import javax.swing.Timer;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import city.cs.engine.SoundClip;
import java.util.List;

public class Player extends Walker {

    private static final Shape playerShape = new PolygonShape(0.62f,0.78f, 0.86f,-0.51f, 0.47f,-1.74f, -0.29f,-1.72f, -0.62f,-0.43f, -0.36f,0.89f);
    private static final BodyImage leftImage = new BodyImage("data/ninja_standing_flip.png", 4);
    private static final BodyImage rightImage = new BodyImage("data/ninja_standing.png", 4);

    // Running Images (Right)
    private static final BodyImage[] runningRightImages = {
            new BodyImage("data/ninja_running.png", 4),
            new BodyImage("data/ninja_running_1.png", 4),
            new BodyImage("data/ninja_running_2.png", 4),
            new BodyImage("data/ninja_running_3.png", 4),
            new BodyImage("data/ninja_running_4.png", 4),
            new BodyImage("data/ninja_running_5.png", 4)
    };

    // Running Images (Left)
    private static final BodyImage[] runningLeftImages = {
            new BodyImage("data/ninja_running_flip.png", 4),
            new BodyImage("data/ninja_running_flip_1.png", 4),
            new BodyImage("data/ninja_running_flip_2.png", 4),
            new BodyImage("data/ninja_running_flip_3.png", 4),
            new BodyImage("data/ninja_running_flip_4.png", 4),
            new BodyImage("data/ninja_running_flip_5.png", 4)
    };

    private static final BodyImage[] jumpingRightImages = {
            new BodyImage("data/ninja_jumping.png", 4),
            new BodyImage("data/ninja_jumping_1.png", 4),
            new BodyImage("data/ninja_jumping_2.png", 4),
            new BodyImage("data/ninja_jumping_3.png", 4),
            new BodyImage("data/ninja_jumping_4.png", 4),
            new BodyImage("data/ninja_jumping_5.png", 4),
            new BodyImage("data/ninja_jumping_6.png", 4),
            new BodyImage("data/ninja_jumping_7.png", 4)
    };

    private static final BodyImage[] jumpingLeftImages = {
            new BodyImage("data/ninja_jumping_flip.png", 4),
            new BodyImage("data/ninja_jumping_flip_1.png", 4),
            new BodyImage("data/ninja_jumping_flip_2.png", 4),
            new BodyImage("data/ninja_jumping_flip_3.png", 4),
            new BodyImage("data/ninja_jumping_flip_4.png", 4),
            new BodyImage("data/ninja_jumping_flip_5.png", 4),
            new BodyImage("data/ninja_jumping_flip_6.png", 4),
            new BodyImage("data/ninja_jumping_flip_7.png", 4)
    };

    private static final BodyImage[] attackRight = {
            new BodyImage("data/ninja_attack.png", 4),
            new BodyImage("data/ninja_attack_1.png", 4),
            new BodyImage("data/ninja_attack_2.png", 4),
            new BodyImage("data/ninja_attack_3.png", 4),
            new BodyImage("data/ninja_attack_4.png", 4)
    };

    private static final BodyImage[] attackLeft = {
            new BodyImage("data/ninja_attack_flip.png", 4),
            new BodyImage("data/ninja_attack_flip_1.png", 4),
            new BodyImage("data/ninja_attack_flip_2.png", 4),
            new BodyImage("data/ninja_attack_flip_3.png", 4),
            new BodyImage("data/ninja_attack_flip_4.png", 4)
    };

    private static final BodyImage[] deathRight = {
            new BodyImage("data/ninja_fall.png", 4),
            new BodyImage("data/ninja_fall_1.png", 4),
            new BodyImage("data/ninja_fall_2.png", 3),
            new BodyImage("data/ninja_fall_3.png", 3),
            new BodyImage("data/ninja_fall_4.png", 3),
    };

    private static final BodyImage[] deathLeft = {
            new BodyImage("data/ninja_fall_flipped.png", 4),
            new BodyImage("data/ninja_fall_flipped_1.png", 4),
            new BodyImage("data/ninja_fall_flipped_2.png", 3),
            new BodyImage("data/ninja_fall_flipped_3.png", 3),
            new BodyImage("data/ninja_fall_flipped_4.png", 3),
    };

    private boolean onGround; //Track if player is touching the ground
    private boolean facingRight = true; // Track player direction
    private boolean isAttacking = false;
    private Timer attackAnimationTimer;
    private int attackFrame = 0;
    private Timer animationTimer;
    private int animationIndex = 0;
    private boolean inAir = false;
    private Timer jumpAnimationTimer;
    private int jumpAnimationIndex = 0;
    private int coinsCollected = 0;
    private boolean isDead = false;
    private Timer deathAnimationTimer;
    private int deathFrame = 0;

    private int credits;
    private SoundClip swordSound;

    private Game game; // Store a reference to the Game instance

    public boolean isAlive() {
        return !isDead;  // The player is alive if isDead is false
    }

    public Player(World world, Game game) {
        super(world, playerShape);
        this.addImage(rightImage);
        this.game = game; // Assign the game instance
        try {
            swordSound = new SoundClip("data/swordsound.wav"); // Load the sword sound
            swordSound.setVolume(0.8);
        } catch (Exception e) {
            System.out.println("Error loading sword sound: " + e);
        }

        // Timer for animation
        animationTimer = new Timer(100, new ActionListener() { // 100ms interval
            @Override
            public void actionPerformed(ActionEvent e) {
                cycleRunningAnimation();
            }
        });

        jumpAnimationTimer = new Timer(100, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cycleJumpingAnimation();
            }
        });

        attackAnimationTimer = new Timer(100, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                playAttackAnimation();
            }
        });

        // Add a collision listener to detect when the player is on the ground
        this.addCollisionListener(new CollisionListener() {
            @Override
            public void collide(CollisionEvent e) {
                if (e.getOtherBody() instanceof StaticBody) {
                    onGround = true;
                }
            }
        });

        // Add a destruction listener to reset onGround when leaving a surface
        this.addDestructionListener(new DestructionListener() {
            @Override
            public void destroy(DestructionEvent e) {
                if (e.getSource() instanceof StaticBody) {
                    onGround = false;
                }
            }
        });

        // Set up collision listener for coin collection
        this.addCollisionListener(new CollisionListener() {
            @Override
            public void collide(CollisionEvent e) {
                // Check if the player collides with a coin
                if (e.getOtherBody() instanceof Coin) {
                    Coin coin = (Coin) e.getOtherBody();
                    // Increment the coin counter and destroy the coin
                    coinsCollected++;
                    coin.destroy();
                }
            }
        });
    }

    public void startRunningAnimation() {
        if (!animationTimer.isRunning()) {
            animationIndex = 0;
            animationTimer.start();
        }
    }

    public void stopRunningAnimation() {
        animationTimer.stop();
        this.removeAllImages();
        this.addImage(facingRight ? rightImage : leftImage);
    }

    private void cycleRunningAnimation() {
        if (animationIndex >= runningRightImages.length) {
            animationIndex = 0; // Loop back to start
        }
        this.removeAllImages();

        if (facingRight) {
            this.addImage(runningRightImages[animationIndex]); // Right-facing animation
        } else {
            this.addImage(runningLeftImages[animationIndex]); // Left-facing animation
        }

        animationIndex++;
    }

    public void startJumpingAnimation() {
        if (!jumpAnimationTimer.isRunning()) {
            jumpAnimationIndex = 0;
            jumpAnimationTimer.start();
        }
    }

    private void cycleJumpingAnimation() {
        if (jumpAnimationIndex < jumpingRightImages.length) {
            this.removeAllImages();

            if (facingRight) {
                this.addImage(jumpingRightImages[jumpAnimationIndex]);
            } else {
                this.addImage(jumpingLeftImages[jumpAnimationIndex]);
            }

            jumpAnimationIndex++;
        } else {
            jumpAnimationTimer.stop();
        }
    }

    public void attack() {
        if (!isAttacking) {
            isAttacking = true;
            if (swordSound != null) {
                swordSound.play();
            }
            attackFrame = 0;
            attackAnimationTimer.start();
            checkEnemyHit();
        }
    }

    public void shootShuriken() {
        // Get the direction the player is facing
        Vec2 velocity = facingRight ? new Vec2(10, 0) : new Vec2(-10, 0); // Adjust velocity for shuriken speed
        Vec2 spawnPosition = this.getPosition().add(facingRight ? new Vec2(1, 0) : new Vec2(-1, 0));

        // Create the shuriken and set its velocity
        new Shuriken(this.getWorld(), spawnPosition, velocity);
    }

    private void playAttackAnimation() {
        if (attackFrame < attackRight.length) {
            this.removeAllImages();
            this.addImage(facingRight ? attackRight[attackFrame] : attackLeft[attackFrame]);
            attackFrame++;
        } else {
            attackAnimationTimer.stop();
            isAttacking = false;
            this.removeAllImages();
            this.addImage(facingRight ? rightImage : leftImage);
        }
    }

    private void checkEnemyHit() {
        List<DynamicBody> bodies = this.getWorld().getDynamicBodies();
        for (DynamicBody body : bodies) {
            if (body instanceof Enemy) {
                Enemy enemy = (Enemy) body;
                float distance = this.getPosition().sub(enemy.getPosition()).length();
                if (distance < 4f) { // Attack range
                    enemy.destroy();
                    // Update the number of defeated enemies
                    game.incrementEnemiesDefeated();
                }
            }
        }
    }

    // Method to update the player's image based on direction
    public void setPlayerImage(boolean isFacingRight) {
        if (this.facingRight != isFacingRight) {
            this.facingRight = isFacingRight;
            this.removeAllImages();
            if (isFacingRight) {
                this.addImage(rightImage);
            } else {
                this.addImage(leftImage);
            }
        }
    }

    public void die() {
        if (!isDead) {
            isDead = true;
            this.removeAllImages();
            playDeathAnimation();
        }
    }

    // After animation ends, show Game Over screen
    private void playDeathAnimation() {
        deathAnimationTimer = new Timer(200, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (deathFrame < deathRight.length) {
                    removeAllImages();
                    addImage(facingRight ? deathRight[deathFrame] : deathLeft[deathFrame]);
                    deathFrame++;
                } else {
                    deathAnimationTimer.stop();
                    new GameOverScreen(game); // Show Game Over screen
                    destroy(); // Remove player
                }
            }
        });
        deathAnimationTimer.start();
    }

    public boolean isOnGround() {
        return onGround;
    }

    public int getCredits() {
        return credits;
    }

    public void setCredits(int credits) {
        this.credits = credits;
    }

    public int getAnimationIndex() {
        return animationIndex;
    }

    public void setAnimationIndex(int animationIndex) {
        this.animationIndex = animationIndex;
    }

    public int getCoinsCollected() {
        return coinsCollected;
    }

    public void setInAir(boolean inAir) {
        this.inAir = inAir;
    }
}
