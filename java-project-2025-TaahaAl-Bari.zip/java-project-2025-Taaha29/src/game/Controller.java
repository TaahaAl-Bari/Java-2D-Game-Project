package game;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import org.jbox2d.common.Vec2;

public class Controller implements KeyListener {
    private Player player;
    private static final float SPEED = 12;
    private static final float JUMP_FORCE = 13;

    public Controller(Player player) {
        this.player = player;
    }

    @Override
    public void keyPressed(KeyEvent e) {
        int key = e.getKeyCode();
        if (key == KeyEvent.VK_F) {
            player.attack();
        }

        // Shuriken shoot key
        if (key == KeyEvent.VK_S) {
            player.shootShuriken();
        }

        if (key ==KeyEvent.VK_LEFT) {
            player.setLinearVelocity(new Vec2(-SPEED, player.getLinearVelocity().y));
            player.setPlayerImage(false); // Switch to left-facing image
            player.startRunningAnimation(); // Start Left-Running Animation
        } else if (key ==KeyEvent.VK_RIGHT) {
            player.setLinearVelocity(new Vec2(SPEED, player.getLinearVelocity().y));
            player.setPlayerImage(true); // Switch to right-facing image
            player.startRunningAnimation(); // Start Right-Running Animation
        } else if (key ==KeyEvent.VK_SPACE) {
            if (player.getLinearVelocity().y == 0) { // prevent double jump
                player.setLinearVelocity(new Vec2(player.getLinearVelocity().x, JUMP_FORCE));
                player.setInAir(true);
                player.startJumpingAnimation();
            }
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        int key = e.getKeyCode();

        if (key == KeyEvent.VK_LEFT || key == KeyEvent.VK_RIGHT) {
            player.setLinearVelocity(new Vec2(0, player.getLinearVelocity().y));
            player.stopRunningAnimation(); // Stop running animation when moving
        }
    }

    @Override
    public void keyTyped(KeyEvent e) {
        // Not used
    }
}
