package game;

import city.cs.engine.*;
import city.cs.engine.Shape;
import org.jbox2d.common.Vec2;
import javax.swing.JFrame;
import java.awt.*;
import java.io.IOException;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;

/**
 * Your main game entry point
 */
public class Game {
    private GameWorld world;
    private GameView view;
    private Player player;
    private Enemy enemy1;
    private Controller controller;
    private JFrame frame;
    private JFrame debugView;
    private int coinCount;

    private int totalEnemiesToDefeat = 2; // 2 enemies
    private int enemiesDefeated = 0; // Tracks how many enemies the player has taken down

    private SoundManager backgroundMusic;

    public int getEnemiesDefeated() {
        return enemiesDefeated;
    }

    public int getTotalEnemiesToDefeat() {
        return totalEnemiesToDefeat;
    }

    public Player getPlayer() {
        return player;
    }


    /** Initialise a new Game. */
    public Game() {
        coinCount = 0;

        //1. make an empty game world
        GameWorld world = new GameWorld();

        // make a view to look into the game world
        view = new GameView(world, 1200, 600, this);

        // Create the player and add to world
        player = new Player(world, this); // Pass to (current Game instance)
        player.setPosition(new Vec2(-26, -9));
        player.addCollisionListener(new StageClearListener(this)); // Collision Listener when Player collides with Sign
        player.addCollisionListener(new CoinPickup(this));

        // Create the Second enemy
        enemy1 = new Enemy(world, 22f, 8f);

        // Attach collision listener
        player.addCollisionListener(new EnemyCollision(player));

        // Attach controller to listen for key presses
        Controller controller = new Controller(player);

        //4. create a Java window (frame) and add the game
        //   view to it
        frame = new JFrame("City Game");
        frame.add(view);
        frame.addKeyListener(controller);

        // enable the frame to quit the application
        // when the x button is pressed
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationByPlatform(true);
        // don't let the frame be resized
        frame.setResizable(false);
        // size the frame to fit the world view
        frame.pack();
        // finally, make the frame visible
        frame.setVisible(true);

        backgroundMusic = new SoundManager("data/ninjagotheme.wav");
        backgroundMusic.playLoop();

        //optional: uncomment this to make a debugging view
        // debugView = new DebugViewer(world, 1200, 600);

        // start our game world simulation!
        world.start();
    }

    public void incrementEnemiesDefeated() {
        enemiesDefeated++;
    }

    public void collectCoin() {
        coinCount++; // Increment coin count when a coin is collected
    }

    public int getCoinCount() {
        return coinCount;  // Return the current coin count
    }

    // Restart the game by creating a new instance
    public void restart() {
        if (debugView != null) {
            debugView.dispose(); // Close the old debug viewer
        }
        frame.dispose(); // Close the current game window

        if (backgroundMusic != null) {
            backgroundMusic.stop();  // Stop the music before restarting
        }

        new Game(); // Create a new instance of the game
    }

    /** Run the game. */
    public static void main(String[] args) {

        new Game();
    }
}
