package game;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GameOverScreen extends JFrame {
    private Game game;

    public GameOverScreen(Game game) {
        this.game = game; // Store reference to the game
        setTitle("Game Over");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JLabel titleLabel = new JLabel("Game Over", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        add(titleLabel, BorderLayout.CENTER);

        JButton tryAgainButton = new JButton("Try Again");
        tryAgainButton.setFont(new Font("Arial", Font.BOLD, 18));
        tryAgainButton.addActionListener(e -> {
            dispose();
            game.restart(); // Restart the game correctly
        });

        add(tryAgainButton, BorderLayout.SOUTH);
        setLocationRelativeTo(null);
        setVisible(true);
    }
}
