package game;


import city.cs.engine.*;
import org.jbox2d.common.Vec2;

public class StageClearSign extends StaticBody {
    private static final Shape signShape = new BoxShape(2, 2);
    private static final BodyImage signImage = new BodyImage("data/stageclearsign.png", 6.5f);

    public StageClearSign(World world, Vec2 position) {
        super(world, signShape);
        addImage(signImage);
        setPosition(position);
    }
}
