package game;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;
import javax.swing.Timer;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Enemy extends Walker implements StepListener {
    private static final Shape enemyShape = new PolygonShape(
            -0.6f, -1.4f, 0.6f, -1.4f, 0.9f, -0.5f, 0.5f, 1.2f, -0.5f, 1.2f, -0.9f, -0.5f
    );

    private static final BodyImage[] runningRightImages = {
            new BodyImage("data/enemyhi(0).png", 4),
            new BodyImage("data/enemyhi(1).png", 4),
            new BodyImage("data/enemyhi(2).png", 4),
            new BodyImage("data/enemyhi(3).png", 4),
            new BodyImage("data/enemyhi(4).png", 4),
            new BodyImage("data/enemyhi(5).png", 4),
            new BodyImage("data/enemyhi(6).png", 4),
    };

    private static final BodyImage[] runningLeftImages = {
            new BodyImage("data/enemyhi_flipped(0).png", 4),
            new BodyImage("data/enemyhi_flipped(1).png", 4),
            new BodyImage("data/enemyhi_flipped(2).png", 4),
            new BodyImage("data/enemyhi_flipped(3).png", 4),
            new BodyImage("data/enemyhi_flipped(4).png", 4),
            new BodyImage("data/enemyhi_flipped(5).png", 4),
            new BodyImage("data/enemyhi_flipped(6).png", 4),
    };

    private boolean movingRight = true;
    private Timer animationTimer;
    private int animationIndex = 0;
    private float leftBound = -11f;
    private float rightBound = 11f;
    private float speed = 3f;

    public Enemy(World world, float leftBound, float rightBound) {
        super(world, enemyShape);
        this.leftBound = leftBound;
        this.rightBound = rightBound;

        this.setPosition(new Vec2(leftBound, 5f)); // Position at the top Platform
        this.addImage(runningRightImages[0]);

        world.addStepListener(this); // Ensure movement logic is executed

        // Animation timer
        animationTimer = new Timer(100, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateAnimation();
            }
        });
        animationTimer.start();
    }

    @Override
    public void preStep(StepEvent stepEvent) {
        // Move the enemy
        if (movingRight) {
            this.startWalking(speed);
        } else {
            this.startWalking(-speed);
        }

        // Check if the enemy reached the patrol boundary
        if (this.getPosition().x >= rightBound) {
            movingRight = false;
        } else if (this.getPosition().x <= leftBound) {
            movingRight = true;
        }
    }

    @Override
    public void postStep(StepEvent stepEvent) {}

    private void updateAnimation() {
        this.removeAllImages();

        if (movingRight) {
            this.addImage(runningRightImages[animationIndex]);
        } else {
            this.addImage(runningLeftImages[animationIndex]);
        }

        animationIndex = (animationIndex + 1) % runningRightImages.length;
    }
}
