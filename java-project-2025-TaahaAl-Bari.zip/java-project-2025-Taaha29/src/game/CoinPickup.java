package game;

import city.cs.engine.*;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import java.io.IOException;

public class CoinPickup implements CollisionListener {
    private Game game;
    private SoundClip coinSound;

    public CoinPickup(Game game) {
        this.game = game;
        try {
            coinSound = new SoundClip("data/coinsound.wav");
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
            System.out.println("Error loading coin sound");
        }
    }

    @Override
    public void collide(CollisionEvent e) {
        if (e.getOtherBody() instanceof Coin) {
            e.getOtherBody().destroy(); // Remove the coin
            if (coinSound != null) {
                coinSound.play(); // Play the coin sound
            }
            game.collectCoin(); // Increment coin counter
        }
    }
}
