package game;

import city.cs.engine.*;
import city.cs.engine.Shape;
import org.jbox2d.common.Vec2;

import java.util.ArrayList;
import java.util.List;

public class GameWorld extends World {
    private List<Coin> coins = new ArrayList<>();
    private Coin coin;

    public GameWorld() {
        super();

        // Create a new coin and add it to the world
        Coin coin = new Coin(this);
        coin.setPosition(new Vec2(-25, 0));
        coins.add(coin);

        Coin coin1 = new Coin(this);
        coin1.setPosition(new Vec2(-12, -6));
        coins.add(coin1);

        Coin coin2 = new Coin(this);
        coin2.setPosition(new Vec2(25, 11));
        coins.add(coin2);

        Coin coin3 = new Coin(this);
        coin3.setPosition(new Vec2(-4, -8));
        coins.add(coin3);

        Coin coin4 = new Coin(this);
        coin4.setPosition(new Vec2(4, -11));
        coins.add(coin4);

        Coin coin5 = new Coin(this);
        coin5.setPosition(new Vec2(15, -8));
        coins.add(coin5);

        // Add step listener to update each coin's bobbing individually
        this.addStepListener(new StepListener() {
            @Override
            public void preStep(StepEvent e) {
                for (Coin c : coins) {
                    c.update();
                }
            }

            @Override
            public void postStep(StepEvent e) {}
        });

        // Add stage clear sign at the end of the level
        StageClearSign stageClearSign = new StageClearSign(this, new Vec2(25, -12));

        // make the ground
        Shape shape = new BoxShape(30f, 0.5f);
        StaticBody ground = new StaticBody(this, shape);
        ground.setPosition(new Vec2(0f, -14.5f));

        // Apply texture to the ground
        BodyImage groundTexture = new BodyImage("data/platformtexture.png", 19.1f);
        ground.addImage(groundTexture);

        // Left Wall
        Shape wallShape = new BoxShape(0.5f, 15);
        StaticBody leftWall = new StaticBody(this, wallShape);
        leftWall.setPosition(new Vec2(-29.5f, 0f)); // Adjust position to align with ground

        // Apply texture to the Left Wall
        BodyImage wallTexture = new BodyImage("data/walls.png", 46f);
        leftWall.addImage(wallTexture);

        // Right Wall
        StaticBody rightWall = new StaticBody(this, wallShape);
        rightWall.setPosition(new Vec2(29.5f, 0));

        // Apply texture to the Right Wall
        rightWall.addImage(wallTexture);

        // Middle Vertical Platform Wall
        Shape middleWallShape = new BoxShape(0.5f, 8.5f);
        StaticBody middleWall = new StaticBody(this, middleWallShape);
        middleWall.setPosition(new Vec2(-7f, -5.5f));

        // Apply texture to the Middle Vertical Wall
        BodyImage middleWallTexture = new BodyImage("data/walls.png", 26f);
        middleWall.addImage(middleWallTexture);

        // make the character
//        Player player = new Player(this);
//        player.setPosition(new Vec2(7, -9));

        //**move** here the rest of the code from Game.java that
        //populates the World - add platforms, Student, etc.
        //(don't add anything related to the view)
        // make a suspended platform

        // Floating Platform 1
        Shape platformShape = new BoxShape(4f, 0.5f);
        StaticBody platform1 = new StaticBody(this, platformShape);
        platform1.setPosition(new Vec2(-11.5f, -8.56f));

        // Apply texture to Floating Platform 1
        BodyImage smallPlatformTexture = new BodyImage("data/smallplatforms.png", 10f);
        platform1.addImage(smallPlatformTexture);

        // Floating Platform 2
        StaticBody platform2 = new StaticBody(this, platformShape);
        platform2.setPosition(new Vec2(-25f, -3f));

        // Apply texture to Floating Platform 2
        platform2.addImage(smallPlatformTexture);

        // Create an enemy on the Long Horizontal Platform At the Top
        float leftBound = -11f; // Set the left patrol limit
        float rightBound = 11f; // Set the right patrol limit
        Enemy enemy = new Enemy(this, leftBound, rightBound);

        // Long Horizontal Platform At the Top
        Shape longPlatformShape = new BoxShape(15f, 0.5f);
        StaticBody longPlatform = new StaticBody(this, longPlatformShape);
        longPlatform.setPosition(new Vec2(4f, 3.5f));

        // Apply texture to Long Horizontal Platform at the Top
        BodyImage longPlatformTexture = new BodyImage("data/longplatforms.png", 10f);
        longPlatform.addImage(longPlatformTexture);

        // Long Horizontal Platform underneath it
        StaticBody lowerLongPlatform = new StaticBody(this, longPlatformShape);
        lowerLongPlatform.setPosition(new Vec2(14f, -5.5f));

        // Apply texture to Long Horizontal Platform Underneath It
        lowerLongPlatform.addImage(longPlatformTexture);

        // Ceiling Platform
        float ceilingPlatformWidth = 30f;
        Shape ceilingPlatformShape = new BoxShape(ceilingPlatformWidth, 0.5f);
        StaticBody ceilingPlatform = new StaticBody(this, ceilingPlatformShape);
        ceilingPlatform.setPosition(new Vec2(0f, 14.5f));

        // Apply texture to the Ceiling Platform
        BodyImage ceilingTexture = new BodyImage("data/ceilings.png", 19.3f);
        ceilingPlatform.addImage(ceilingTexture);
    }
}