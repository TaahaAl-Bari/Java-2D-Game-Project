package game;

import city.cs.engine.*;
import org.jbox2d.common.Vec2;

public class Shuriken extends Projectile {

    private static final Shape shurikenShape = new PolygonShape(
            -0.5f,0f, 0f,0.5f, 0.5f,0f, 0f,-0.5f
    );
    private static final BodyImage shurikenImage = new BodyImage("data/shuriken.png", 1);

    public Shuriken(World world, Vec2 position, Vec2 velocity) {
        super(world, shurikenShape);
        addImage(shurikenImage);
        setPosition(position);
        setLinearVelocity(velocity);

        addCollisionListener(new CollisionListener() {
            @Override
            public void collide(CollisionEvent e) {
                if (e.getOtherBody() instanceof Enemy) {
                    e.getOtherBody().destroy();
                    destroy(); // Shuriken disappears
                } else if (e.getOtherBody() instanceof StaticBody) {
                    destroy(); // Hit wall/ground = destroy
                }
            }
        });
    }
}
